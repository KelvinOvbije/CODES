import React, { useState } from "react";
import "./App.css";

function App() {
  const [randomImages, setRandomImages] = useState([]);
  const [dogImage, setDogImage] = useState("");
  const [uploadedImageUrl, setUploadedImageUrl] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
  };

  const fetchRandomImages = async () => {
    try {
      const response = await fetch("http://localhost:9000/api/random-images");
      if (!response.ok) {
        throw new Error("Failed to fetch images");
      }
      const { images } = await response.json();
      setRandomImages(images);
    } catch (error) {
      console.error("Error fetching images:", error);
      alert("Failed to load images. Please try again later.");
    }
  };

  const fetchRandomDogImage = async () => {
    try {
      const response = await fetch("https://dog.ceo/api/breeds/image/random");
      const { message } = await response.json();
      setDogImage(message);
    } catch (error) {
      console.error("Error fetching dog image:", error);
    }
  };

  const handleImageUpload = async (e) => {
    e.preventDefault();
    if (!selectedFile) {
      alert("Please select a file before uploading.");
      return;
    }
    const formData = new FormData();
    formData.append("dogImage", selectedFile);

    try {
      const response = await fetch("http://localhost:9000/upload", {
        method: "POST",
        body: formData,
      });
      const { filename } = await response.json();
      setUploadedImageUrl(`http://localhost:9000/uploads/${filename}`);
    } catch (error) {
      console.error("Error uploading image:", error);
    }
  };

  return (
    <div>
      <h1 className="header">Gallery Random Image</h1>
      <div className="container1">
        {randomImages.map((img, index) => (
          <img key={index} src={img} alt={`Random ${index}`} className="image-style" />
        ))}
        <button className="buttons" onClick={fetchRandomImages}>Get Images</button>
      </div>

      <h2 className="header"> Image of Random Dog</h2>
      <div className="container2">
        {dogImage && <img className="image-style" src={dogImage} alt="Random Dog" />}
        <button className="buttons" onClick={fetchRandomDogImage}>Get Random Dog Images</button>
      </div>

      <h2 className="header"> Dog Image Upload</h2>
      <form onSubmit={handleImageUpload}>
        <input type="file" name="dogImage" onChange={handleFileChange} />
        <button className="buttons" type="submit">Upload</button>
      </form>
      {uploadedImageUrl && (
        <div>
          <h2 className="header">Uploaded Dog Image:</h2>
          <img className="image-style" src={uploadedImageUrl} alt="Uploaded Dog" />
        </div>
      )}
    </div>
  );
}

export default App;
